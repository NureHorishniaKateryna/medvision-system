import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInput } from '@angular/material/input';
import { MatButton } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import {MatProgressSpinner} from '@angular/material/progress-spinner';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    CommonModule,
    MatFormFieldModule,
    MatInput,
    ReactiveFormsModule,
    MatSelectModule,
    MatCardModule,
    MatButton,
    RouterLink,
    MatProgressSpinner
  ],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  form: FormGroup;
  loading = false;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService
  ) {
    this.form = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      role: ['patient', Validators.required],

      // Patient
      birthDate: [''],
      gender: [''],

      // Doctor
      position: [''],
      medicalInstitution: [''],
      department: [''],
      licenseNumber: ['']
    });
  }

  get role() {
    return this.form.get('role')?.value;
  }

  onSubmit() {
    if (this.form.invalid) return;
    this.loading = true;

    const role = this.role;
    let request: any;

    if (role === 'patient') {
      request = {
        name: this.form.value.name,
        email: this.form.value.email,
        password: this.form.value.password,
        birthDate: this.form.value.birthDate,
        gender: this.form.value.gender
      };
      this.authService.registerPatient(request).subscribe(this.handleSuccess());
    } else if (role === 'doctor') {
      request = {
        name: this.form.value.name,
        email: this.form.value.email,
        password: this.form.value.password,
        position: this.form.value.position,
        medicalInstitution: this.form.value.medicalInstitution,
        department: this.form.value.department,
        licenseNumber: this.form.value.licenseNumber
      };
      this.authService.registerDoctor(request).subscribe(this.handleSuccess());
    } else {
      request = {
        name: this.form.value.name,
        email: this.form.value.email,
        password: this.form.value.password
      };
      this.authService.registerAdmin(request).subscribe(this.handleSuccess());
    }
  }

  handleSuccess(): () => void {
    return () => {
      this.loading = false;

      switch (this.role) {
        case 'PATIENT':
          this.router.navigate(['/dashboard/patient']);
          break;
        case 'DOCTOR':
          this.router.navigate(['/dashboard/doctor']);
          break;
        case 'ADMIN':
          this.router.navigate(['/dashboard/admin']);
          break;
        default:
          this.router.navigate(['/login']);
      }
    };
  }

}
