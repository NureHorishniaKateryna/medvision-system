import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatButtonModule } from '@angular/material/button';
import { RouterModule } from '@angular/router';
import { PatientService } from '../../services/patient.service';
import {PageHeaderComponent} from '../page-header/page-header.component';

@Component({
  selector: 'app-patient-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatListModule,
    MatIconModule,
    MatButtonModule,
    RouterModule,
    PageHeaderComponent
  ],
  templateUrl: './patient-dashboard.component.html',
  styleUrl: './patient-dashboard.component.css'
})
export class PatientDashboardComponent implements OnInit {
  private patientService = inject(PatientService);
  analyses: any[] = [];

  ngOnInit(): void {
    this.patientService.getAllAnalyses().subscribe(data => {
      this.analyses = data.map((item: any) => ({
        id: item.imageAnalysisId,
        date: item.creationDatetime?.split('T')[0] || '—',
        status: item.analysisDiagnosis || 'Невідомо',
        comment: item.imageFile?.imageFileName || '—'
      }));
    });
  }
}
