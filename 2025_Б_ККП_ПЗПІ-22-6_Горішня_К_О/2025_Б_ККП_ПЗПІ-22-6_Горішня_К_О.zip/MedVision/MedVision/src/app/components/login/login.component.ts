import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInput } from '@angular/material/input';
import { MatButton } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { AuthService } from '../../services/auth.service'; // подкорректируй путь
import { CommonModule } from '@angular/common';
import { MatProgressSpinner } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    MatFormFieldModule,
    MatInput,
    MatCardModule,
    MatSelectModule,
    ReactiveFormsModule,
    MatButton,
    MatProgressSpinner
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  form: FormGroup;
  loading = false;
  error: string | null = null;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService
  ) {
    this.form = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.form.invalid) return;

    this.loading = true;
    this.error = null;

    this.authService.login(this.form.value).subscribe({
      next: (profile) => {
        this.loading = false;

        const role = profile.role || profile.userRole;
        switch (role) {
          case 'PATIENT':
            this.router.navigate(['/dashboard/patient']);
            break;
          case 'DOCTOR':
            this.router.navigate(['/dashboard/doctor']);
            break;
          case 'ADMIN':
            this.router.navigate(['/dashboard/admin']);
            break;
          default:
            this.router.navigate(['/login']);
        }
      },
      error: () => {
        this.loading = false;
        this.error = 'Невірний email або пароль';
      }
    });
  }

}
