import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { MatDialog } from '@angular/material/dialog';
import { MatTableModule } from '@angular/material/table';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { UserDialogComponent } from '../user-dialog/user-dialog.component';
import {PageHeaderComponent} from '../page-header/page-header.component';

@Component({
  selector: 'app-users-dashboard',
  standalone: true,
  templateUrl: './users-dashboard.component.html',
  styleUrl: './users-dashboard.component.css',
  imports: [
    CommonModule,
    MatTableModule,
    MatCardModule,
    MatButtonModule,
    PageHeaderComponent
  ]
})
export class UsersDashboardComponent implements OnInit {
  users: any[] = [];
  displayedColumns: string[] = ['id','username', 'email', 'role'];

  constructor(private userService: UserService, private dialog: MatDialog) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    this.userService.getAllUsers().subscribe((data) => {
      this.users = data;
    });
  }

  openUserDialog(user: any) {
    const dialogRef = this.dialog.open(UserDialogComponent, {
      data: user,
      width: '400px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result?.refresh) {
        this.loadUsers();
      }
    });
  }
}
