import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatCard } from '@angular/material/card';
import { MatList, MatListItem } from '@angular/material/list';
import { NgForOf } from '@angular/common';
import { MatButton, MatIconButton, MatMiniFabButton } from '@angular/material/button';
import { MatLine } from '@angular/material/core';
import { MatIcon } from '@angular/material/icon';
import { PageHeaderComponent } from '../page-header/page-header.component';
import { DoctorService } from '../../services/doctor.service';
import { AnalysisService } from '../../services/analysis.service';
import {MatCheckbox} from '@angular/material/checkbox';
import {CompareDialogComponent} from '../compare-dialog/compare-dialog.component';
import {MatDialog} from '@angular/material/dialog';
import { MatLabel } from '@angular/material/form-field';

@Component({
  selector: 'app-patient-details-page',
  standalone: true,
  templateUrl: './patient-details-page.component.html',
    imports: [
        MatCard,
        MatList,
        MatListItem,
        NgForOf,
        MatLine,
        MatIcon,
        MatMiniFabButton,
        PageHeaderComponent,
        MatCheckbox,
        MatButton,
        MatLabel
    ],
  styleUrl: './patient-details-page.component.css'
})
export class PatientDetailsPageComponent implements OnInit {
  patientId!: number;
  patient: any;
  analyses: any[] = [];
  selectedAnalysisIds: number[] = [];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private doctorService: DoctorService,
    private analysisService: AnalysisService,
    private dialog: MatDialog,
  ) {}

  ngOnInit(): void {
    this.patientId = +this.route.snapshot.paramMap.get('id')!;

    this.doctorService.getPatientById(this.patientId).subscribe((data) => {
      let genderLabel = 'Невідомо';
      switch (data.gender) {
        case 'MALE':
          genderLabel = 'Чоловіча';
          break;
        case 'FEMALE':
          genderLabel = 'Жіноча';
          break;
        case 'OTHER':
          genderLabel = 'Інше';
          break;
      }

      this.patient = {
        id: data.patientId,
        name: data.user.userName,
        email: data.user.email,
        birthDate: data.birthDate,
        gender: genderLabel,
        heightCm: data.heightCm,
        weightKg: data.weightKg,
        address: data.address,
        allergies: data.allergies || 'Немає',
        chronicDiseases: data.chronicDiseases || 'Немає'
      };
    });

    this.analysisService.getAnalysesByPatientId(this.patientId).subscribe((analyses) => {
      this.analyses = analyses.map((a: any) => ({
        id: a.imageAnalysisId,
        date: a.creationDatetime?.split('T')[0] || '—',
        status: 'Готово',
        comment: a.analysisDiagnosis || '—'
      }));
    });
  }

  addAnalysis() {
    this.router.navigate(['/doctor/patients', this.patientId, 'analyses', 'new']);
  }

  toggleSelect(id: number) {
    const index = this.selectedAnalysisIds.indexOf(id);

    if (index > -1) {
      this.selectedAnalysisIds.splice(index, 1);
    } else {
      if (this.selectedAnalysisIds.length === 2) {
        this.selectedAnalysisIds.shift();
      }

      this.selectedAnalysisIds.push(id);
    }

  }

  isSelected(id: number): boolean {
    return this.selectedAnalysisIds.includes(id);
  }

  compareSelected() {
    const [fromId, toId] = this.selectedAnalysisIds;
    console.log('Compare:', fromId, toId);
    this.analysisService.getComparison(fromId, toId).subscribe((data) => {
      this.dialog.open(CompareDialogComponent, {
        data,
        width: '700px',
        maxHeight: '90vh',
        panelClass: 'compare-dialog'
      });
    });
  }

  openAnalysis(analysisId: number) {
    this.router.navigate(['/doctor/patients', this.patientId, 'analyses', analysisId]);
  }
}
