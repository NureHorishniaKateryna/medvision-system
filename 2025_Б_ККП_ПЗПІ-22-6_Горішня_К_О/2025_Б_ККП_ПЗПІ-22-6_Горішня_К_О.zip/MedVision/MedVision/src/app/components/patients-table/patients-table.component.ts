import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-patients-table',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatInputModule,
    MatSelectModule,
    FormsModule
  ],
  templateUrl: './patients-table.component.html',
  styleUrl: './patients-table.component.css'
})
export class PatientsTableComponent {
  displayedColumns = ['name', 'email', 'analyses', 'status'];

  allPatients = [
    { name: 'Іван Петренко', email: 'ivan@med.com', analyses: 3, status: 'Активний' },
    { name: 'Олена Сидоренко', email: 'olena@med.com', analyses: 1, status: 'Потребує уваги' },
    { name: 'Артем Коваль', email: 'artem@med.com', analyses: 2, status: 'У нормі' },
    { name: 'Марія Шевченко', email: 'maria@med.com', analyses: 4, status: 'Активний' }
  ];

  searchText: string = '';
  selectedStatus: string = '';

  get filteredPatients() {
    return this.allPatients.filter(p =>
      (!this.searchText || p.name.toLowerCase().includes(this.searchText.toLowerCase())) &&
      (!this.selectedStatus || p.status === this.selectedStatus)
    );
  }
}
