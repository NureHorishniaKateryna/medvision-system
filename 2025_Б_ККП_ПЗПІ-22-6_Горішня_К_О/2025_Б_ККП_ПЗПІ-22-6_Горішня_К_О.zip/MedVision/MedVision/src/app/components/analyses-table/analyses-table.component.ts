import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-analyses-table',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatInputModule,
    MatSelectModule,
    FormsModule
  ],
  templateUrl: './analyses-table.component.html',
  styleUrl: './analyses-table.component.css'
})
export class AnalysesTableComponent {
  displayedColumns = ['patient', 'date', 'status', 'comment'];

  allData = [
    { patient: 'Іван Петренко', date: '2025-04-22', status: 'Готовий', comment: 'Патологія виявлена' },
    { patient: 'Олена Сидоренко', date: '2025-04-20', status: 'У нормі', comment: 'Без патологій' },
    { patient: 'Артем Коваль', date: '2025-04-18', status: 'Потребує уваги', comment: 'Рекомендовано консультацію' },
    { patient: 'Марія Шевченко', date: '2025-04-16', status: 'У нормі', comment: 'Все в межах норми' }
  ];

  searchText: string = '';
  selectedStatus: string = '';

  get filteredData() {
    return this.allData.filter(a =>
      (!this.searchText || a.patient.toLowerCase().includes(this.searchText.toLowerCase())) &&
      (!this.selectedStatus || a.status === this.selectedStatus)
    );
  }
}
