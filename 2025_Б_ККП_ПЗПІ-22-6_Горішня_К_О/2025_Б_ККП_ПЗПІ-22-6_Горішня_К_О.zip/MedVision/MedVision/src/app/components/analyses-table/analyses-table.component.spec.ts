import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalysesTableComponent } from './analyses-table.component';

describe('AnalysesTableComponent', () => {
  let component: AnalysesTableComponent;
  let fixture: ComponentFixture<AnalysesTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AnalysesTableComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AnalysesTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
