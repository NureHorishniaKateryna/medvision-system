import { Component, OnInit, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    RouterLink
  ],
  templateUrl: './user-profile.component.html',
  styleUrl: './user-profile.component.css'
})
export class UserProfileComponent implements OnInit {
  private authService = inject(AuthService);
  private router = inject(Router);
  form: FormGroup;
  role: string = '';

  constructor(private fb: FormBuilder) {
    this.form = this.fb.group({
      name: [''],
      email: [''],
      role: [{ value: '', disabled: true }],
      position: [''],
      medicalInstitution: [''],
      department: [''],
      licenseNumber: [''],
      achievements: [''],
      education: [''],
      birthDate: [''],
      lastExamDate: [''],
      address: [''],
      gender: [''],
      heightCm: [''],
      weightKg: [''],
      chronicDiseases: [''],
      allergies: ['']
    });


  }


  ngOnInit(): void {
    this.authService.getProfile().subscribe(profile => {
      this.role = profile.userRole || profile.role;

      this.form.patchValue({
        name: profile.name || '',
        email: profile.email || '',
        role: this.mapRole(this.role),
        medicalInstitution: profile.medicalInstitution || '',
        position: profile.position || '',
        department: profile.department || '',
        licenseNumber: profile.licenseNumber || '',
        achievements: profile.achievements || '',
        education: profile.education || '',
        birthDate: profile.birthDate || '',
        lastExamDate: profile.lastExamDate || '',
        address: profile.address || '',
        gender: profile.gender || '',
        heightCm: profile.heightCm || '',
        weightKg: profile.weightKg || '',
        chronicDiseases: profile.chronicDiseases || '',
        allergies: profile.allergies || ''
      });


      if (this.role === 'ADMIN') {
        this.form.get('name')?.disable();
        this.form.get('email')?.disable();
      }

      this.form.markAsPristine();
    });
  }


  save() {
    const raw = this.form.getRawValue();

    if (this.role === 'DOCTOR') {
      const doctorData = {
        name: raw.name,
        email: raw.email,
        position: raw.position,
        department: raw.department,
        medicalInstitution: raw.medicalInstitution,
        licenseNumber: raw.licenseNumber,
        achievements: raw.achievements,
        education: raw.education
      };

      this.authService.editDoctor(doctorData).subscribe({
        next: () => this.form.markAsPristine(),
        error: (err) => {
          console.error('Validation error:', err.error);
        }
      });

    } else if (this.role === 'PATIENT') {
      const patientData = {
        name: raw.name,
        email: raw.email,
        birthDate: raw.birthDate,
        lastExamDate: raw.lastExamDate,
        gender: raw.gender,
        address: raw.address,
        heightCm: raw.heightCm,
        weightKg: raw.weightKg,
        chronicDiseases: raw.chronicDiseases,
        allergies: raw.allergies
      };

      this.authService.editPatient(patientData).subscribe({
        next: () => this.form.markAsPristine(),
        error: (err) => {
          console.error('Validation error:', err.error);
        }
      });
    }


  }

  private mapRole(role: string): string {
    switch (role?.toUpperCase()) {
      case 'DOCTOR':
        return 'Лікар';
      case 'PATIENT':
        return 'Пацієнт';
      case 'ADMIN':
        return 'Адміністратор';
      default:
        return 'Користувач';
    }
  }

  get dashboardLink(): string {
    switch (this.role?.toUpperCase()) {
      case 'DOCTOR':
        return '/dashboard/doctor';
      case 'PATIENT':
        return '/dashboard/patient';
      case 'ADMIN':
        return '/dashboard/admin';
      default:
        return '/dashboard';
    }
  }

}
