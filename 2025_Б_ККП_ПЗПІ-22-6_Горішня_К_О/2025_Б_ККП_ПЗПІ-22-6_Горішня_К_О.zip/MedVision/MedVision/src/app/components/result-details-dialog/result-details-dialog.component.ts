import { Component, Inject } from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogModule, MatDialogRef} from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import {MatButton} from '@angular/material/button';
import {MatCard} from '@angular/material/card';
import {MatIconModule} from '@angular/material/icon';

@Component({
  selector: 'app-result-details-dialog',
  standalone: true,
  imports: [CommonModule, MatDialogModule, MatButton, MatIconModule, MatCard],
  templateUrl: './result-details-dialog.component.html',
  styleUrl: './result-details-dialog.component.css'
})
export class ResultDetailsDialogComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<ResultDetailsDialogComponent>
  ) {}

  onClose() {
    this.dialogRef.close();
  }

  download() {
    // TODO: замінити на справжню генерацію PDF
    alert(`PDF для аналізу ${this.data.id} поки не реалізовано :)`);
  }
}
