import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResultDetailsPageComponent } from './result-details-page.component';

describe('ResultDetailsPageComponent', () => {
  let component: ResultDetailsPageComponent;
  let fixture: ComponentFixture<ResultDetailsPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ResultDetailsPageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ResultDetailsPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
