import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { NgApexchartsModule } from 'ng-apexcharts';
import {
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis
} from 'ng-apexcharts';
import { PatientService } from '../../services/patient.service';
import {PageHeaderComponent} from '../page-header/page-header.component';
import {MatButton} from '@angular/material/button';

@Component({
  selector: 'app-result-details-page',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatIconModule,
    NgApexchartsModule,
    PageHeaderComponent,
    MatButton
  ],
  templateUrl: './result-details-page.component.html',
  styleUrl: './result-details-page.component.css'
})
export class ResultDetailsPageComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private patientService = inject(PatientService);

  analysisId!: number;
  analysis: any = null;

  chartSeries: ApexAxisChartSeries = [];
  chartOptions: ApexChart = { type: 'bar', height: 300 };
  xAxis: ApexXAxis = {
    categories: ['Загальна точність класифікації', 'Повнота виявлення патологій', 'Точність виявлення патологій']
  };

  ngOnInit(): void {
    this.analysisId = +this.route.snapshot.paramMap.get('id')!;
    this.patientService.getAnalysisById(this.analysisId).subscribe(data => {
      this.analysis = data;

      this.chartSeries = [
        {
          name: 'Метрика',
          data: [
            data.analysisAccuracy || 0,
            data.analysisRecall || 0,
            data.analysisPrecision || 0
          ]
        }
      ];
    });
  }

  getImageUrl(file: any): string | null {
    const url = file?.imageFileUrl;
    if (!url || typeof url !== 'string') return null;

    return url.replace(
      'gs://medvision-458613.appspot.com/',
      'https://medvision-458613.appspot.com/'
    );
  }

  downloadPdf(): void {
    this.patientService.getAnalysisPdf(this.analysisId).subscribe(blob => {
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `analysis-${this.analysisId}.pdf`;
      link.click();
      window.URL.revokeObjectURL(url);
    });
  }

}
