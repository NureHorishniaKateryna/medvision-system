import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';
import { CreatePatientDialogComponent } from '../create-patient-dialog/create-patient-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { DoctorService } from '../../services/doctor.service';
import { AuthService } from '../../services/auth.service';
import {PageHeaderComponent} from '../page-header/page-header.component';

@Component({
  selector: 'app-doctor-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    FormsModule,
    MatTableModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    PageHeaderComponent
  ],
  templateUrl: './doctor-dashboard.component.html',
  styleUrl: './doctor-dashboard.component.css'
})
export class DoctorDashboardComponent implements OnInit {
  displayedColumns = ['name', 'email', 'birthDate', 'gender', 'height', 'weight'];
  search = '';
  filterStatus = '';

  patients: any[] = [];
  doctorName = 'Профіль';
  filterGender = '';
  filterHeightMin: number | null = null;
  filterHeightMax: number | null = null;
  filterWeightMin: number | null = null;
  filterWeightMax: number | null = null;
  filterBirthDateFrom: string = '';
  filterBirthDateTo: string = '';

  constructor(
    private router: Router,
    private dialog: MatDialog,
    private doctorService: DoctorService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.authService.getProfile().subscribe(user => {
      this.doctorName = user?.userName || user?.name || 'Профіль';
    });

    this.doctorService.getPatients().subscribe(patients => {
      this.patients = patients || [];
    });
  }

  get filteredPatients() {
    return this.patients.filter(p => {
      const nameMatch = !this.search || p.user?.userName?.toLowerCase().includes(this.search.toLowerCase());
      const genderMatch = !this.filterGender || p.gender === this.filterGender;
      const heightMatch =
        (this.filterHeightMin == null || p.heightCm >= this.filterHeightMin) &&
        (this.filterHeightMax == null || p.heightCm <= this.filterHeightMax);
      const weightMatch =
        (this.filterWeightMin == null || p.weightKg >= this.filterWeightMin) &&
        (this.filterWeightMax == null || p.weightKg <= this.filterWeightMax);
      const birthDateMatch =
        (!this.filterBirthDateFrom || p.birthDate >= this.filterBirthDateFrom) &&
        (!this.filterBirthDateTo || p.birthDate <= this.filterBirthDateTo);

      return nameMatch && genderMatch && heightMatch && weightMatch && birthDateMatch;
    });
  }


  openCreatePatientDialog() {
    const dialogRef = this.dialog.open(CreatePatientDialogComponent, {
      width: '400px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log('Новий пацієнт:', result);
        this.patients.push({
          id: Math.max(...this.patients.map(p => p.patientId)) + 1,
          user: {
            userName: `${result.firstName} ${result.lastName}`,
            email: result.email
          },
          analyses: [],
          status: 'Активний'
        });
      }
    });
  }

  openPatient(patientId: number) {
    this.router.navigate(['/doctor/patients', patientId]);
  }
}
