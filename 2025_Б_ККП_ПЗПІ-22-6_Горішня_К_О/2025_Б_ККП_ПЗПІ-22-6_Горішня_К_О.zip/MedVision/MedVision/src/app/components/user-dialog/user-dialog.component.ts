import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { UserService } from '../../services/user.service';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-user-dialog',
  standalone: true,
  templateUrl: './user-dialog.component.html',
  imports: [CommonModule, FormsModule, MatDialogModule, MatButtonModule, MatSelectModule]
})
export class UserDialogComponent {
  roles = ['ADMIN', 'DOCTOR', 'PATIENT'];
  selectedRole: string;

  constructor(
    @Inject(MAT_DIALOG_DATA) public user: any,
    private dialogRef: MatDialogRef<UserDialogComponent>,
    private userService: UserService
  ) {
    this.selectedRole = user.userRole;
  }

  updateRole() {
    this.userService.updateUserRole(this.user.userId, this.selectedRole).subscribe(() => {
      this.dialogRef.close({ refresh: true });
    });
  }

  deleteUser() {
    this.userService.deleteUser(this.user.userId).subscribe(() => {
      this.dialogRef.close({ refresh: true });
    });
  }

  cancel() {
    this.dialogRef.close();
  }
}
