import {Component, ElementRef, HostListener, OnInit, ViewChild} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { DoctorService } from '../../services/doctor.service';
import { AuthService } from '../../services/auth.service';
import { PageHeaderComponent } from '../page-header/page-header.component';
import {AnalysisService} from '../../services/analysis.service';
import {MatList, MatListItem} from '@angular/material/list';
import {MatOption, MatSelect } from '@angular/material/select';
import {MatTooltip} from '@angular/material/tooltip';


@Component({
  selector: 'app-analysis-page',
  standalone: true,
  templateUrl: './analysis-page.component.html',
  styleUrl: './analysis-page.component.css',
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatButtonModule,
    MatInputModule,
    MatIconModule,
    PageHeaderComponent,
    MatList,
    MatListItem,
    MatSelect,
    MatOption,
    MatTooltip
  ]
})
export class AnalysisPageComponent implements OnInit {
  analysisId!: string;
  isNew = false;
  file: File | null = null;
  imagePreview: string | null = null;
  heatmapPreview: string | null = null;
  result: string | null = null;
  diagnosis: string = '';
  analysisDetails: string = '';
  treatmentRecommendations: string = '';
  reason: string = '';
  note: string = '';
  diagnosisHistory: any[] = [];
  notes: any[] = [];
  imgNotes: any[] = [];
  doctorId!: number;
  patientId!: number;
  analysis: any = null;
  analysisStatus: string = '';
  @ViewChild('imageRef', { static: false }) imageRef!: ElementRef<HTMLImageElement>;

  drawing = false;
  drawingFinished = false;
  noteText = '';
  rect = { x: 0, y: 0, width: 0, height: 0 };

  private startX = 0;
  private startY = 0;

  @HostListener('window:mousemove', ['$event'])
  onGlobalMouseMove(event: MouseEvent) {
    this.draw(event);
  }

  @HostListener('window:mouseup', ['$event'])
  onGlobalMouseUp(event: MouseEvent) {
    this.finishDrawing();
  }


  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private doctorService: DoctorService,
    private authService: AuthService,
    private analysisService: AnalysisService
  ) {}

  ngOnInit(): void {
    this.analysisId = this.route.snapshot.paramMap.get('analysesId')!;
    this.patientId = +this.route.snapshot.paramMap.get('id')!;
    this.isNew = this.analysisId === 'new';

    const user = this.authService.getUser();
    this.doctorId = user?.userId || user?.id;

    if (!this.isNew) {
      this.doctorService.getAnalysisById(+this.analysisId).subscribe(data => {
        this.analysis = data;
        this.result = data.analysisDiagnosis;
        this.diagnosis = data.analysisDiagnosis || '';
        this.analysisDetails = data.analysisDetails || '';
        this.treatmentRecommendations = data.treatmentRecommendations || '';
        this.imagePreview = this.getUrlFromGs(data.imageFile?.imageFileUrl);
        this.heatmapPreview = this.getUrlFromGs(data.heatmapFile?.imageFileUrl);
      });
      this.analysisService.getAnalysisStatus(+this.analysisId).subscribe((res) => {
        this.analysisStatus = res;
      });
      this.analysisService.getDiagnosisHistory(+this.analysisId).subscribe(history => {
        this.diagnosisHistory = history;
      });
      this.analysisService.getNotesByAnalysisId(+this.analysisId).subscribe(notes => {
        this.notes = notes;
      });
      this.analysisService.getAnalysisImageNotes(+this.analysisId).subscribe(notes => {
        this.imgNotes = notes;
      });
    }
  }

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length) {
      this.file = input.files[0];

      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreview = reader.result as string;
      };
      reader.readAsDataURL(this.file);
    }
  }

  save() {
    if (!this.file || !this.doctorId || !this.patientId) return;

    this.doctorService.analyzeImage(this.patientId, this.doctorId, this.file).subscribe((res: string) => {
      const match = /ID:\s*(\d+)/.exec(res);
      const newId = match ? +match[1] : null;

      if (newId) {
        window.location.href = `/doctor/patients/${this.patientId}/analyses/${newId}`;
      } else {
        alert('Не вдалося отримати ID обстеження');
      }
    });
  }


  saveDiagnosis() {
    if (!this.diagnosis.trim() || !this.reason.trim()) return;

    this.analysisService.addDiagnosis(
      +this.analysisId,
      this.doctorId,
      this.diagnosis,
      this.reason,
      this.analysisDetails,
      this.treatmentRecommendations
    ).subscribe(() => {
      alert('Діагноз збережено');
      this.analysisService.getDiagnosisHistory(+this.analysisId).subscribe(history => {
        this.diagnosisHistory = history;
      });
      this.reason = '';
    });

  }


  saveNote() {
    if (!this.note.trim()) return;

    this.doctorService.addAnalysisNote(+this.analysisId, this.doctorId, {
      noteText: this.note,
      noteAreaX: 0,
      noteAreaY: 0,
      noteAreaWidth: 0,
      noteAreaHeight: 0
    }).subscribe(() => {
      alert('Нотатка збережена');
      this.note = '';
    });
  }

  getUrlFromGs(gsUrl: string): string {
    return gsUrl?.startsWith('gs://')
      ? gsUrl.replace('gs://medvision-458613.appspot.com/', 'https://medvision-458613.appspot.com/')
      : gsUrl;
  }

  updateStatus(newStatus: string) {
    this.analysisService.updateAnalysisStatus(+this.analysisId, newStatus).subscribe(() => {
      this.analysisStatus = newStatus;
      alert('Статус оновлено');
    });
  }

  startDrawing(event: MouseEvent) {
    const rect = this.imageRef.nativeElement.getBoundingClientRect();
    this.startX = event.clientX - rect.left;
    this.startY = event.clientY - rect.top;
    this.rect = { x: this.startX, y: this.startY, width: 0, height: 0 };
    this.drawing = true;
    this.drawingFinished = false;
  }

  draw(event: MouseEvent) {
    if (!this.drawing) return;
    const rect = this.imageRef.nativeElement.getBoundingClientRect();
    const currentX = event.clientX - rect.left;
    const currentY = event.clientY - rect.top;

    this.rect.width = Math.abs(currentX - this.startX);
    this.rect.height = Math.abs(currentY - this.startY);
    this.rect.x = Math.min(currentX, this.startX);
    this.rect.y = Math.min(currentY, this.startY);
  }

  finishDrawing() {
    this.drawing = false;
    this.drawingFinished = true;
  }

  cancelNote() {
    this.drawingFinished = false;
    this.noteText = '';
  }

  saveAreaNote() {
    if (!this.noteText.trim()) return;
    this.doctorService.addAnalysisNote(+this.analysisId, this.doctorId, {
      noteText: this.noteText,
      noteAreaX: this.rect.x,
      noteAreaY: this.rect.y,
      noteAreaWidth: this.rect.width,
      noteAreaHeight: this.rect.height
    }).subscribe(() => {
      alert('Нотатку збережено');
      this.noteText = '';
      this.drawingFinished = false;
      this.analysisService.getAnalysisImageNotes(+this.analysisId).subscribe(n => this.imgNotes = n);
    });
  }

}
