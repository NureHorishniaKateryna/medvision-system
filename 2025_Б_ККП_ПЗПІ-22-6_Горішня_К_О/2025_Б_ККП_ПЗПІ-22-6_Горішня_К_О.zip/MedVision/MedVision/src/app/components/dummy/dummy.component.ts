import { Component } from '@angular/core';

@Component({
  selector: 'app-dummy',
  imports: [],
  templateUrl: './dummy.component.html',
  standalone: true,
  styleUrl: './dummy.component.css'
})
export class DummyComponent {

}
