import { Component, Input, OnInit, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { AuthService } from '../../services/auth.service';
import { MatTooltip } from '@angular/material/tooltip';
import {PatientService} from '../../services/patient.service';
import {MatMenu, MatMenuItem, MatMenuTrigger} from '@angular/material/menu';

@Component({
  selector: 'app-page-header',
  standalone: true,
  imports: [CommonModule, RouterLink, MatIconModule, MatButtonModule, MatTooltip, MatMenuTrigger, MatMenu, MatMenuItem],
  templateUrl: './page-header.component.html',
  styleUrl: './page-header.component.css'
})
export class PageHeaderComponent implements OnInit {
  @Input() backLink?: any;

  role: string = '';
  fullName: string = '';
  unviewedCount = 0;
  unviewedAnalyses: any[] = [];

  private authService = inject(AuthService);
  private router = inject(Router);
  private patientService = inject(PatientService);

  ngOnInit(): void {
    const user = this.authService.getUser();
    if (user) {
      this.fullName = user.userName || `${user.name || ''}`.trim();
      this.role = this.mapRole(user.userRole || user.role);

      if ((user.userRole || user.role)?.toUpperCase() === 'PATIENT') {
        this.patientService.getUnviewedAnalyses().subscribe((analyses) => {
          this.unviewedAnalyses = analyses;
          this.unviewedCount = analyses.length;
        });
      }
    }
  }

  markOneAndNavigate(id: number) {
    this.patientService.markAnalysisAsViewed(id).subscribe(() => {
      window.location.href = `/results/${id}`;
    });
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  private mapRole(role: string): string {
    switch (role?.toUpperCase()) {
      case 'DOCTOR': return 'Лікар';
      case 'PATIENT': return 'Пацієнт';
      case 'ADMIN': return 'Адміністратор';
      default: return 'Користувач';
    }
  }
}
