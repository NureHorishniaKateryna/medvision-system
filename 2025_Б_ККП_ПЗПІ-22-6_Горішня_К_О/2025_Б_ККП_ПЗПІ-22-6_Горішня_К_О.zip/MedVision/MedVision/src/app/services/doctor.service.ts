import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  private readonly baseUrl = 'https://medvision-app-eebbebcgb4fpf7e7.centralus-01.azurewebsites.net/api/doctor';

  constructor(private http: HttpClient) {}

  // GET /patients
  getPatients(): Observable<any> {
    return this.http.get(`${this.baseUrl}/patients`);
  }

  // GET /patients/{id}
  getPatientById(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/patients/${id}`);
  }

// POST /images/analyze?patientId=&doctorId=
  analyzeImage(patientId: number, doctorId: number, file: File): Observable<string> {
    const formData = new FormData();
    formData.append('file', file);

    const params = new HttpParams()
      .set('patientId', patientId.toString())
      .set('doctorId', doctorId.toString());

    return this.http.post(`${this.baseUrl}/images/analyze`, formData, {
      params,
      responseType: 'text'
    });
  }


  // POST /analyses/{analysesId}/notes?doctorId=
  addAnalysisNote(analysesId: number, doctorId: number, note: {
    noteText: string,
    noteAreaX: number,
    noteAreaY: number,
    noteAreaWidth: number,
    noteAreaHeight: number
  }): Observable<any> {
    const params = new HttpParams().set('doctorId', doctorId);
    return this.http.post(`${this.baseUrl}/analyses/${analysesId}/notes`, note, { params });
  }

  // GET /analysis/{id}
  getAnalysisById(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/analysis/${id}`);
  }

  // GET /heatmap/{id}
  getHeatmap(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/heatmap/${id}`, { responseType: 'blob' });
  }

}
