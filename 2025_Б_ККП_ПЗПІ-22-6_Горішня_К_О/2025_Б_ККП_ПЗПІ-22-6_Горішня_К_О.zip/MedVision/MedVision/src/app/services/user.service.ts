import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private readonly baseUrl = 'https://medvision-app-eebbebcgb4fpf7e7.centralus-01.azurewebsites.net/api/users';

  constructor(private http: HttpClient) {}

  // Отримати список усіх користувачів
  getAllUsers(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }

  // Отримати користувача за ID
  getUserById(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  // Змінити роль користувача
  updateUserRole(id: number, newRole: string): Observable<any> {
    return this.http.patch(`${this.baseUrl}/${id}/role`, { newRole });
  }

  // Видалити користувача
  deleteUser(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }
}
