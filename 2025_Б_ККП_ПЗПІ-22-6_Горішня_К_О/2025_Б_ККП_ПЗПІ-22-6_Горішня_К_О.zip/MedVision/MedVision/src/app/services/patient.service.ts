import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

  private readonly baseUrl = 'https://medvision-app-eebbebcgb4fpf7e7.centralus-01.azurewebsites.net/api/patient';

  constructor(private http: HttpClient) {}

  // Отримати теплову карту за ID
  getHeatmap(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/heatmap/${id}`);
  }

  // Отримати всі аналізи поточного пацієнта
  getAllAnalyses(): Observable<any> {
    return this.http.get(`${this.baseUrl}/analyses`);
  }

  // Отримати конкретний аналіз
  getAnalysisById(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/analyses/${id}`);
  }

  // Отримати PDF-версію аналізу
  getAnalysisPdf(id: number): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/analyses/pdf/${id}`, { responseType: 'blob' });
  }

  getUnviewedAnalyses(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/analyses/unviewed`);
  }

  markAnalysisAsViewed(id: number): Observable<any> {
    return this.http.post(`${this.baseUrl}/analyses/${id}/mark-viewed`, {});
  }
}
