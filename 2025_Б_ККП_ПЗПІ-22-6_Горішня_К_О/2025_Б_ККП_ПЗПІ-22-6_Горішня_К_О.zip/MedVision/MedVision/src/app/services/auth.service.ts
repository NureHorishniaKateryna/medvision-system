import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, switchMap, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private baseUrl = 'https://medvision-app-eebbebcgb4fpf7e7.centralus-01.azurewebsites.net/api/auth';

  constructor(private http: HttpClient) {}

  // ===== Реєстрація =====
  registerPatient(data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/register/patient`, data).pipe(
      switchMap(() => this.login({ email: data.email, password: data.password }))
    );
  }

  registerDoctor(data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/register/doctor`, data).pipe(
      switchMap(() => this.login({ email: data.email, password: data.password }))
    );
  }

  registerAdmin(data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/register/admin`, data).pipe(
      switchMap(() => this.login({ email: data.email, password: data.password }))
    );
  }

  // ===== Авторизація =====
  login(data: { email: string; password: string }): Observable<any> {
    return this.http.post(`${this.baseUrl}/login`, data).pipe(
      tap((res: any) => {
        if (res?.token) {
          localStorage.setItem('token', res.token);
        }
      }),
      switchMap(() => this.getProfile()) // одразу після логіну — запит профілю
    );
  }

  // ===== Профіль =====
  getProfile(): Observable<any> {
    return this.http.get(`${this.baseUrl}/profile`).pipe(
      tap((profile) => {
        localStorage.setItem('user', JSON.stringify(profile));
      })
    );
  }

  // ===== Редагування профілю =====
  editPatient(data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/edit/patient`, data);
  }

  editDoctor(data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/edit/doctor`, data);
  }

  // ===== Локальні методи =====
  getToken(): string | null {
    return localStorage.getItem('token');
  }

  getUser(): any {
    const raw = localStorage.getItem('user');
    return raw ? JSON.parse(raw) : null;
  }

  logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }
}
