import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({providedIn: 'root'})
export class AnalysisService {
  private readonly baseUrl = 'https://medvision-app-eebbebcgb4fpf7e7.centralus-01.azurewebsites.net/api';

  constructor(private http: HttpClient) {
  }

  // GET /api/analysis
  getAllAnalyses(): Observable<any> {
    return this.http.get(`${this.baseUrl}/analysis`);
  }

  // GET /api/analysis/{id}
  getAnalysisById(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/analysis/${id}`);
  }

  // DELETE /api/analysis/{id}
  deleteAnalysisById(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/analysis/${id}`);
  }

  // GET /api/analysis/patient/{patientId}
  getAnalysesByPatientId(patientId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/analysis/patient/${patientId}`);
  }

  // GET /api/analysis/doctor/{doctorId}
  getAnalysesByDoctorId(doctorId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/analysis/doctor/${doctorId}`);
  }

  // GET /api/analysis-note/{id}
  getNoteById(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/analysis-note/${id}`);
  }

  // POST /api/analysis-note/{id}
  addNoteToAnalysis(id: number, noteData: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/analysis-note/${id}`, noteData);
  }

  // DELETE /api/analysis-note/{id}
  deleteNoteById(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/analysis-note/${id}`);
  }

  // GET /api/analysis-note/by-analysis/{analysisId}
  getNotesByAnalysisId(analysisId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/analysis-note/by-analysis/${analysisId}`);
  }

  getComparison(fromId: number, toId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/analysis/compare?fromId=${fromId}&toId=${toId}`);
  }


  // GET /analysis/{analysisId}/diagnosis-history
  getDiagnosisHistory(analysisId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/diagnosis/analysis/${analysisId}`);
  }

  // GET /analysis/{id}/status
  getAnalysisStatus(id: number): Observable<any> {
    return this.http.get<{ status: string }>(`${this.baseUrl}/analysis/${id}/status`);
  }

// PATCH /analysis/{id}/status
  updateAnalysisStatus(id: number, status: string): Observable<any> {
    return this.http.patch(`${this.baseUrl}/analysis/${id}/status`, {status});
  }

  // POST /api/diagnosis
  addDiagnosis(analysisId: number,
               doctorId: number,
               diagnosisText: string,
               reason: string,
               analysisDetails: string,
               treatmentRecommendations: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/diagnosis`, {
      analysisId,
      doctorId,
      diagnosisText,
      reason,
      analysisDetails,
      treatmentRecommendations
    });
  }

  // GET /analysis/{id}/status
  getAnalysisImageNotes(id: number): Observable<any> {
    return this.http.get<{ status: string }>(`${this.baseUrl}/analysis-note/by-analysis/${id}`);
  }

  // GET /api/analysis/compare/pdf?fromId=X&toId=Y — Download comparison PDF
  downloadComparisonPdf(fromId: number, toId: number): Observable<Blob> {
    const url = `${this.baseUrl}/analysis/compare/pdf?fromId=${fromId}&toId=${toId}`;
    return this.http.get(url, {responseType: 'blob'});
  }

}
