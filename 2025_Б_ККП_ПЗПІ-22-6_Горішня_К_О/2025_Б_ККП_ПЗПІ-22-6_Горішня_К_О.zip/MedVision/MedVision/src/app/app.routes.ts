import { Routes } from '@angular/router';

import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';
import { PatientDashboardComponent } from './components/patient-dashboard/patient-dashboard.component';
import { DoctorDashboardComponent } from './components/doctor-dashboard/doctor-dashboard.component';
import { AnalysesTableComponent } from './components/analyses-table/analyses-table.component';
import { PatientsTableComponent } from './components/patients-table/patients-table.component';
import { ResultDetailsPageComponent } from './components/result-details-page/result-details-page.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { PatientDetailsPageComponent } from './components/patient-details-page/patient-details-page.component';
import { AnalysisPageComponent } from './components/analysis-page/analysis-page.component';
import { UsersDashboardComponent } from './components/users-dashboard/users-dashboard.component';
import { DummyComponent } from './components/dummy/dummy.component';
import { AuthGuard } from './guards/auth.guard';


export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },

  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },

  { path: 'dashboard', component: DummyComponent, canActivate: [ ] },

  // Dashboards
  { path: 'dashboard/patient', component: PatientDashboardComponent, canActivate: [AuthGuard, ], data: { roles: ['PATIENT'] } },
  { path: 'dashboard/doctor', component: DoctorDashboardComponent, canActivate: [AuthGuard, ], data: { roles: ['DOCTOR'] } },
  { path: 'dashboard/admin', component: UsersDashboardComponent, canActivate: [AuthGuard, ], data: { roles: ['ADMIN'] } },

  // Shared protected routes
  { path: 'profile', component: UserProfileComponent, canActivate: [AuthGuard] },
  { path: 'doctor/patients', component: PatientsTableComponent, canActivate: [AuthGuard, ], data: { roles: ['DOCTOR'] } },
  { path: 'doctor/analyses', component: AnalysesTableComponent, canActivate: [AuthGuard, ], data: { roles: ['DOCTOR'] } },
  { path: 'doctor/patients/:id', component: PatientDetailsPageComponent, canActivate: [AuthGuard, ], data: { roles: ['DOCTOR'] } },
  { path: 'doctor/patients/:id/analyses/:analysesId', component: AnalysisPageComponent, canActivate: [AuthGuard, ], data: { roles: ['DOCTOR'] } },

  { path: 'results/:id', component: ResultDetailsPageComponent, canActivate: [AuthGuard, ], data: { roles: ['PATIENT'] } }
];
